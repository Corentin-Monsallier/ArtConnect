package com.project.artconnect.persistence;

import com.project.artconnect.dao.ArtistDao;
import com.project.artconnect.model.Artist;
import java.util.List;

/**
 * JDBC implementation for ArtistDao.
 * TODO: Students must implement this using JDBC and SQL.
 */
public class JdbcArtistDao implements ArtistDao {

@Override
public void save(Artist artist) {

    String sql = "INSERT INTO Artist(bio, website_artist, is_active, id_user) VALUES (?, ?, ?, ?)";

    try (Connection connection = ConnectionManager.getConnection();
        PreparedStatement statement = connection.prepareStatement(sql)
    ){

        statement.setString(1, artist.getBio());
        statement.setString(2, artist.getWebsiteArtist());
        statement.setBoolean(3, artist.isActive());
        statement.setInt(4, artist.getIdUser());

        statement.executeUpdate();

    } catch (SQLException e) {
        e.printStackTrace();
    }
}

@Override
public void save(Artist artist) {

    String sql = "INSERT INTO Artist(bio, website_artist, is_active, id_user) VALUES (?, ?, ?, ?)";

    try (
            Connection connection = ConnectionManager.getConnection();
            PreparedStatement statement = connection.prepareStatement(sql)
    ) {

        statement.setString(1, artist.getBio());
        statement.setString(2, artist.getWebsiteArtist());
        statement.setBoolean(3, artist.isActive());
        statement.setInt(4, artist.getIdUser());

        statement.executeUpdate();

    } catch (SQLException e) {
        e.printStackTrace();
    }
}

@Override
public void update(Artist artist) {
    // TODO: Implement UPDATE artist SET ... WHERE name = ?
    throw new UnsupportedOperationException("JDBC Implementation not yet provided.");
}

@Override
public void delete(String artistName) {
    // TODO: Implement DELETE FROM artist WHERE name = ?
    throw new UnsupportedOperationException("JDBC Implementation not yet provided.");
}

@Override
public List<Artist> findByCity(String city) {
    // TODO: Implement SELECT * FROM artist WHERE city = ?
    throw new UnsupportedOperationException("JDBC Implementation not yet provided.");
}
}