package com.project.artconnect.dao;

import java.sql.SQLException;
import java.util.List;

import com.project.artconnect.model.Artist;

/**
 * Data Access Object for Artist entity.
 */
public interface ArtistDao {
    List<Artist> findAll() throws SQLException;

    void save(Artist artist, User id_user) throws SQLException;

    void update(Artist artist) throws SQLException;

    void delete(String artistName) throws SQLException;

    List<Artist> findByCity(String city) throws SQLException;
}
