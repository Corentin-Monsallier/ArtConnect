package com.project.artconnect.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.project.artconnect.dao.ArtistDao;
import com.project.artconnect.model.Artist;
import com.project.artconnect.util.ConnectionManager;

public class ArtistDaoImpl implements ArtistDao {
    @Override
    public List<Artist> findAll() throws SQLException {
        String query = "SELECT * FROM artists";
        List<Artist> artists = new ArrayList<>();

        try (Connection connection = ConnectionManager.getConnection();
         PreparedStatement statement = connection.prepareStatement(query);
         ResultSet result = statement.executeQuery()) {

            while (result.next()) {
                Artist artist = new Artist();
                artist.setId_artist(id_artist);
                artist.setBio(result.getString("bio")); 
                artist.setWebsite_artist(result.getString("query"));
                artist.getId_user();
                artists.add(artist);
            }
        }
    return artists;
    }

    @Override
    public void save(Artist id_artist, User id_user) throws SQLException {
        String query = "INSERT INTO Artist (bio, website_artist, is_active, id_user) VALUES (?, ?, ?, ?)";
        try (Connection connection = ConnectionManager.getConnection();
        PreparedStatement statement = connection.prepareStatement(query);
        ResultSet result = statement.executeQuery()) {
            statement.setString(1, artist.getBio());
            statement.setString(2, artist.getWebsite());
            statement.setBoolean(3, artist.isActive());
            statement.setInt(4, user.getIdUser());

            statement.executeUpdate();
        }
    }

    @Override
    public void update(Artist artist) throws SQLException {
        String query = "";
    }

    @Override
    public void delete(String artistName) throws SQLException {
        String query = "";
    }

    @Override
    public List<Artist> findByCity(String city) throws SQLException{
        String query = "";
        List<Artist> artists = new ArrayList<>();

        return artists;}
}
